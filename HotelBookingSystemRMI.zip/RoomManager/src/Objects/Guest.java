package Objects;

public class Guest {
	int guestId;
	String guestFirstName;
	String guestLastName;
	String guestRoomId;
	int guestStayDuration;
	
	public Guest(int guestId, String guestFirstName, String guestLastName, String guestRoomId, int guestStayDuration) {
		super();
		this.guestId = guestId;
		this.guestFirstName = guestFirstName;
		this.guestLastName = guestLastName;
		this.guestRoomId = guestRoomId;
		this.guestStayDuration = guestStayDuration;
	}
	
	public int getGuestId() {
		return guestId;
	}

	public void setGuestId(int guestId) {
		this.guestId = guestId;
	}

	public String getGuestFirstName() {
		return guestFirstName;
	}

	public void setGuestFirstName(String guestFirstName) {
		this.guestFirstName = guestFirstName;
	}

	public String getGuestLastName() {
		return guestLastName;
	}

	public void setGuestLastName(String guestLastName) {
		this.guestLastName = guestLastName;
	}

	public String getGuestRoomId() {
		return guestRoomId;
	}

	public void setGuestRoomId(String guestRoomId) {
		this.guestRoomId = guestRoomId;
	}

	public int getGuestStayDuration() {
		return guestStayDuration;
	}

	public void setGuestStayDuration(int guestStayDuration) {
		this.guestStayDuration = guestStayDuration;
	}
}
